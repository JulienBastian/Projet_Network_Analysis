# Informations administratives

Auteur : Persée UAR 3602
Dernière modification du readme : 25/01/2024
Dernière modification du jeu de données : 25/01/2024
Contact : Sitthida Samath, CNRS Persée UAR 3602, sitthida.samath@persee.fr, https://info.persee.fr/
Droits d'utilisations : cf. CGU https://www.persee.fr/cgu


# Description du jeu de données

Le jeu de données a été produit à partir des fichiers de dumps de données liées .rdf du triplestore Persée, disponibles à l'adresse https://data.persee.fr/explorer/demander-un-dump/dumps-collections/

Les fichiers contiennent les métadonnées bibliographiques des documents de chacune des collections de Persée.

Les métadonnées bibliographiques originales ont été filtrées et allégées en conséquence :
- exclusion de la collection "Archives Parlementaires" (hors scope et trop volumineuse) ;
- exclusion des collections bhe, sgeol et shf (dump défectueux) ;
- collection shom limitée à 255 documents (dump défectueux) ;
- données de documents uniquement ;
- manifestations numériques uniquement.

Etat des données documentaires : octobre 2021.


# Structure du répertoire et des données

Les données rdf-xml originales ont été aplaties sous forme de tableaux (dataframes pandas Python).

Pour les champs multi-valués, on trouve une colonne par valeur, avec un indice entre crochets dans le nom des colonnes répétées.
Ex: un article a 3 auteurs -> les valeurs d'auteurs sont dans les 3 colonnes dcterms:creator{URIRef}[0], dcterms:creator{URIRef}[1], dcterms:creator{URIRef}[2]

Pour en savoir plus sur le modèle de données et les intitulés des colonnes, se reporter à l'adresse
https://data.persee.fr/explorer/schemas-de-donnees/
Le niveau pertinent est celui du document.

Le répertoire contient :
- 1 fichier readme.txt
- 9 fichiers de métadonnées bibliographiques .csv: chacun contenant les métadonnées bibliographiques des documents d'un sous-ensemble des collections de Persée. L'ensemble des 9 fichiers reconstitue l'ensemble des collections Persée ayant fait l'objet d'un dump sur data.persee.fr
- (alternative) 9 fichiers de métadonnées bibliographiques .pickle : contenant la même chose que le point précédent sous forme de dataframe pandas sérialisé en pickle
- 1 fichier de correspondance collection-discipline .csv : 2 colonnes collection_id (voir ci-dessous) et label de discipline correspondant

## Convention de nommage des documents

La correspondance entre collection et discipline utilise les codes de collection Persée (collection_id).
Le collection_id ne fait l'objet d'aucune colonne spécifique.
On le trouve dans le nom des documents car les documents sont nommés de manière systématique, sous la formule :
<collection_id>_<ISSN>_<année de publication print>_<code de type de fascicule>_<volume>_<numéro>_<données supplémentaires de localisation/identification>

Ex: assr_0335-5985_1989_num_67_2_1390_t1_0308_0000_1
code collection = assr
ISSN = 0335-5985
date de publication = 1989
code de type de fascicule = num
volume = 67
numéro = 2
autres données de localisation/identification : page 308 etc









